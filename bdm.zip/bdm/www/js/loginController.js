angular.module("bdmApp.loginController", [])

  .controller("loginController", ['$state', 'user', '$q', loginController]);

function loginController($state, user, $q) {
  var _self = this;

  this.changeRoute = function () {
    $state.go('home')
  };

  this.signUpWithGoogle = function () {
    _self.promise = user.logInUser();
    _self.promise.then(
      function (success) {
          _self.changeRoute();
      },function (error) {
          console.log("Wrong User");
      }

    )
  };
}
