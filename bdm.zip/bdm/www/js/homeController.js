angular.module("bdmApp.homeController", [])

  .controller("homeController", ['$state', 'user',homeController]);

function homeController($state, user) {

  this.i = 0;
  this.length = 2;
  this.user = user.getlogInUser();
  
  this.bdmQuestions = [
    {
      Qusetion: "What was Burkina Faso formerly known as ? ",
      Options: ["Lower Volta", "Upper Volta", "The Volta"]
    },
    {
      Qusetion: "What is the name of a person from Burkina Faso ? ",
      Options: ["Burkinabè", "Burkinabais", "Burkina"]
    },
    {
      Qusetion: "Where is Ouagadougou located ? ",
      Options: ["center of the country", "Nord", "between Mali and Senegal"]
    },
    {
      Qusetion: "What nationality are people from Burkina Faso ? ",
      Options: ["Burkinois", "Fasonois", "Burkinabè"]
    }
,
    {
      Qusetion: "Who is the first heads of state of Burkina Faso ? ",
      Options: ["Thomas Sankara", "Maurice Yaméogo", "Norbert Zongo"]
    },
    {
      Qusetion: "Who name the country to Burkina Faso ? ",
      Options: ["Blaise Compaore", "Thomas Sankara", "Sangoulé Lamizana"]
    }
,
    {
      Qusetion: "Who is the current president ? ",
      Options: ["Michel Kafando", "Roch Marc Christian Kaboré", "Maky Sall"]
    },
    {
      Qusetion: "Name an Online Media In Burkina ? ",
      Options: ["Burkina 24", "Sidwaya", "Airtel Burkina"]
    }

  ];

  this.nextQuestion = function () {
    if (this.i < this.bdmQuestions.length-1)
      this.i++;
    else if (this.i >= this.length)
      $state.go('results');
    else
    this.i = this.i;
  }

}
