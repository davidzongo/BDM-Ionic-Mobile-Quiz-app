
angular.module("bdmApp.resultController", [])

  .controller("resultController", [resultController]);

function resultController(){



}
